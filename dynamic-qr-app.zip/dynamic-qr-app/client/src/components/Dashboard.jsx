import React from 'react';
import QRCreator from './QRCreator';
import History from './History';

export default function Dashboard({ user }){
  return (
    <div className="grid">
      <div>
        <QRCreator />
        <div style={{height:18}}></div>
        <History />
      </div>
      <div className="card">
        <h4>Quick Notes</h4>
        <p className="small">When you create a QR the frontend will generate a styled QR that encodes the shortlink the server returned (e.g. http://localhost:4000/r/abc123). That shortlink is what makes the QR dynamic — editing the QR on the server updates the redirect target without changing the QR graphic.</p>
      </div>
    </div>
  );
}
