import React, { useRef, useState, useEffect } from 'react';
import API from '../api';
import QRCodeStyling from 'qr-code-styling';

export default function QRCreator(){
  const [originalUrl, setOriginalUrl] = useState('');
  const [shortLink, setShortLink] = useState('');
  const [qrInstance, setQrInstance] = useState(null);
  const ref = useRef();
  const [logoFile, setLogoFile] = useState(null);
  const [colorMode, setColorMode] = useState('single'); // single, gradient, multicolor
  const [color1, setColor1] = useState('#111827');
  const [color2, setColor2] = useState('#2563eb');
  const [shape, setShape] = useState('square'); // square, dots, rounded

  useEffect(()=>{
    const qr = new QRCodeStyling({
      width: 320,
      height: 320,
      data: 'https://example.com', // placeholder
      image: null,
      dotsOptions: { type: 'rounded' },
      backgroundOptions: { color: "#ffffff" },
    });
    setQrInstance(qr);
    qr.append(ref.current);
    return () => {};
  }, []);

  function updateQRAppearance(data){
    if(!qrInstance) return;
    const dotsType = shape === 'dots' ? 'dots' : shape === 'rounded' ? 'rounded' : 'square';
    const options = {
      data,
      dotsOptions: { type: dotsType, color: color1 },
      backgroundOptions: { color: '#ffffff' },
    };
    if(colorMode === 'gradient'){
      options.cornerSquareOptions = { type: 'square' };
      options.dotsOptions = { type: dotsType };
      options.imageOptions = undefined;
      options.gradient = { type: 'linear', rotation: 0, colorStops: [{ offset: 0, color: color1 }, { offset: 1, color: color2 }] };
    } else if(colorMode === 'multicolor'){
      // fallback: use color1 for now on dots; multi-color more elaborate requires composing SVG — keep simple sample
      options.dotsOptions.color = color1;
    } else {
      options.dotsOptions.color = color1;
    }
    if(logoFile){
      options.image = logoFile;
      options.imageOptions = { crossOrigin: 'anonymous', margin: 5, imageSize: 0.2 };
    } else {
      options.image = null;
    }
    qrInstance.update(options);
  }

  async function createQR(e){
    e.preventDefault();
    try{
      const formData = new FormData();
      formData.append('originalUrl', originalUrl);
      if(logoFile) formData.append('logo', logoFile);
      // meta stores appearance choices so history can preserve them
      const meta = JSON.stringify({ colorMode, color1, color2, shape });
      formData.append('meta', meta);

      const r = await API.post('/qr/create', formData, { headers: {'Content-Type': 'multipart/form-data'} });
      setShortLink(r.data.shortLink);
      // update QR so it encodes the short link
      updateQRAppearance(r.data.shortLink);
    }catch(err){
      alert(err.response?.data?.error || err.message);
    }
  }

  function download(type){
    if(!qrInstance) return;
    if(type === 'png') qrInstance.download({ extension: 'png' });
    if(type === 'svg') qrInstance.download({ extension: 'svg' });
  }

  return (
    <div className="card">
      <h3>Create Dynamic QR</h3>
      <form onSubmit={createQR} style={{display:'grid', gap:8}}>
        <input className="input" placeholder="https://example.com" value={originalUrl} onChange={e=>setOriginalUrl(e.target.value)} />
        <div style={{display:'flex', gap:8, alignItems:'center'}}>
          <div>
            <label className="small">Logo (optional)</label><br/>
            <input type="file" accept="image/*" onChange={e=>setLogoFile(e.target.files[0])} />
          </div>
          <div>
            <label className="small">Color mode</label><br/>
            <select value={colorMode} onChange={e=>setColorMode(e.target.value)}>
              <option value="single">Single</option>
              <option value="gradient">Gradient (2-color)</option>
              <option value="multicolor">Multi (sample)</option>
            </select>
          </div>
          <div>
            <label className="small">Shape</label><br/>
            <select value={shape} onChange={e=>setShape(e.target.value)}>
              <option value="square">Square</option>
              <option value="rounded">Rounded</option>
              <option value="dots">Dots</option>
            </select>
          </div>
        </div>

        <div style={{display:'flex', gap:8}}>
          <input className="input" type="color" value={color1} onChange={e=>setColor1(e.target.value)} />
          <input className="input" type="color" value={color2} onChange={e=>setColor2(e.target.value)} />
          <button className="btn" type="button" onClick={()=> updateQRAppearance(shortLink || originalUrl || 'https://example.com')}>Preview</button>
          <button className="btn btn-primary" type="submit">Generate</button>
        </div>
      </form>

      <div style={{marginTop:12, display:'flex', gap:12}}>
        <div className="qr-canvas" ref={ref}></div>
        <div style={{flex:1}}>
          <div className="small">Short Link (encoded in QR):</div>
          <div style={{wordBreak:'break-all'}}>{shortLink || 'Short link will appear here after creation'}</div>
          <div style={{marginTop:8, display:'flex', gap:8}}>
            <button className="btn" onClick={()=>download('png')}>Download PNG</button>
            <button className="btn" onClick={()=>download('svg')}>Download SVG</button>
          </div>
        </div>
      </div>
    </div>
  );
}
