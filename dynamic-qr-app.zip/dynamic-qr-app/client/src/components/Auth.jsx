import React, {useState} from 'react';
import API, { setAuth } from '../api';

export default function Auth({ onLogin }) {
  const [mode, setMode] = useState('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  async function submit(e){
    e.preventDefault();
    try{
      const url = mode === 'login' ? '/auth/login' : '/auth/signup';
      const r = await API.post(url, { email, password });
      onLogin(r.data);
      setAuth(r.data.token);
    }catch(err){
      alert(err.response?.data?.error || err.message);
    }
  }
  return (
    <form onSubmit={submit} style={{display:'flex', gap:8, alignItems:'center'}}>
      <input className="input" style={{width:240}} value={email} onChange={e=>setEmail(e.target.value)} placeholder="email" />
      <input type="password" className="input" style={{width:180}} value={password} onChange={e=>setPassword(e.target.value)} placeholder="password" />
      <button className="btn btn-primary" type="submit">{mode === 'login' ? 'Login' : 'Sign up'}</button>
      <button type="button" className="btn" onClick={()=>setMode(mode === 'login' ? 'signup' : 'login')}>{mode === 'login' ? 'Switch to signup' : 'Switch to login'}</button>
    </form>
  );
}
