import React, {useEffect, useState} from 'react';
import API from '../api';

export default function History(){
  const [list, setList] = useState([]);
  const [editingId, setEditingId] = useState(null);
  const [newUrl, setNewUrl] = useState('');

  async function fetchHistory(){
    try{
      const r = await API.get('/qr/history');
      setList(r.data.qrs);
    }catch(err){
      console.error(err);
    }
  }
  useEffect(()=>{ fetchHistory(); }, []);

  async function startEdit(qr){
    setEditingId(qr.id);
    setNewUrl(qr.currentUrl || qr.originalUrl);
  }
  async function saveEdit(){
    try{
      await API.put(`/qr/${editingId}`, { currentUrl: newUrl });
      setEditingId(null);
      setNewUrl('');
      fetchHistory();
    }catch(err){ alert(err.response?.data?.error || err.message); }
  }
  async function del(id){
    if(!confirm('Delete QR?')) return;
    try{
      await API.delete(`/qr/${id}`);
      fetchHistory();
    }catch(err){ alert(err.response?.data?.error || err.message); }
  }

  return (
    <div className="card">
      <h4>Your QR History</h4>
      <table className="table">
        <thead>
          <tr><th>Short</th><th>Original</th><th>Active</th><th>Scans</th><th>Created</th><th></th></tr>
        </thead>
        <tbody>
          {list.map(q => (
            <tr key={q.id}>
              <td><a href={`http://localhost:4000/r/${q.shortId}`} target="_blank" rel="noreferrer">/r/{q.shortId}</a></td>
              <td style={{maxWidth:220}}>{q.originalUrl}</td>
              <td style={{maxWidth:220}}>{q.currentUrl}</td>
              <td>{q.scans || 0}</td>
              <td>{q.created_at}</td>
              <td>
                <button className="btn" onClick={()=>startEdit(q)}>Edit</button>
                <button className="btn" onClick={()=>del(q.id)}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {editingId && (
        <div style={{marginTop:12}}>
          <h5>Edit destination</h5>
          <input className="input" value={newUrl} onChange={e=>setNewUrl(e.target.value)} />
          <div style={{marginTop:8}}>
            <button className="btn btn-primary" onClick={saveEdit}>Save</button>
            <button className="btn" onClick={()=>setEditingId(null)}>Cancel</button>
          </div>
        </div>
      )}
    </div>
  );
}
