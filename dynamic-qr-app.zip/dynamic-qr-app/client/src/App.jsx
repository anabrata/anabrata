import React, { useState, useEffect } from 'react';
import Auth from './components/Auth';
import Dashboard from './components/Dashboard';
import { setAuth } from './api';

function App(){
  const [token, setToken] = useState(localStorage.getItem('token'));
  const [user, setUser] = useState(JSON.parse(localStorage.getItem('user') || 'null'));

  useEffect(()=> {
    setAuth(token);
  }, [token]);

  const onLogin = ({ token, user }) => {
    localStorage.setItem('token', token);
    localStorage.setItem('user', JSON.stringify(user));
    setToken(token);
    setUser(user);
  };

  const onLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    setToken(null);
    setUser(null);
    setAuth(null);
  };

  return (
    <div className="container">
      <div className="header">
        <h2>Dynamic QR Generator</h2>
        <div>
          {user ? (
            <div style={{display:'flex', gap:8, alignItems:'center'}}>
              <div className="small">Signed in as {user.email}</div>
              <button className="btn btn-primary" onClick={onLogout}>Logout</button>
            </div>
          ) : <Auth onLogin={onLogin} />}
        </div>
      </div>

      {user ? <Dashboard user={user} /> : (
        <div className="card">
          <h3>Welcome — sign up or login to create dynamic QR codes</h3>
          <p className="small">This demo creates short URLs on the server (dynamic) and the QR encodes that short link. Edit the destination later in History → Edit.</p>
        </div>
      )}
    </div>
  );
}

export default App;
