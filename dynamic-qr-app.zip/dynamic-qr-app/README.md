# Dynamic QR App (Local Demo)

This is a minimal full-stack demo implementing dynamic QR generation with shortlinks + redirect.

## Run server
cd server
npm install
cp .env.example .env
# edit .env if needed
npm run dev   # or npm start

## Run client
cd client
npm install
npm start

Client runs on http://localhost:3000 and server on http://localhost:4000

