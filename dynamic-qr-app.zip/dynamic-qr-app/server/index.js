require('dotenv').config();
const express = require('express');
const cors = require('cors');
const db = require('./db');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const shortid = require('shortid');
const multer = require('multer');
const path = require('path');
const fs = require('fs');

const PORT = process.env.PORT || 4000;
const JWT_SECRET = process.env.JWT_SECRET || 'replace_me';
const APP_HOST = process.env.APP_HOST || `http://localhost:${PORT}`;

const uploadDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir);

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadDir),
  filename: (req, file, cb) => {
    const unique = Date.now() + '-' + Math.round(Math.random()*1e9);
    cb(null, unique + path.extname(file.originalname));
  }
});
const upload = multer({ storage });

const app = express();
app.use(cors());
app.use(express.json());
app.use('/uploads', express.static(uploadDir));

/* --- Helpers --- */
function signToken(user) {
  return jwt.sign({ id: user.id, email: user.email, is_admin: user.is_admin }, JWT_SECRET, { expiresIn: '7d' });
}
function authMiddleware(req, res, next) {
  const h = req.headers.authorization;
  if (!h) return res.status(401).json({ error: 'No auth' });
  const token = h.split(' ')[1];
  try {
    const payload = jwt.verify(token, JWT_SECRET);
    req.user = payload;
    next();
  } catch (e) {
    res.status(401).json({ error: 'Invalid token' });
  }
}

/* --- Auth --- */
app.post('/api/auth/signup', async (req, res) => {
  const { email, password } = req.body;
  if(!email || !password) return res.status(400).json({error:'email+password required'});
  const hash = await bcrypt.hash(password, 10);
  db.run('INSERT INTO users (email, password_hash) VALUES (?,?)', [email, hash], function(err) {
    if (err) return res.status(400).json({ error: err.message });
    const user = { id: this.lastID, email, is_admin: 0 };
    const token = signToken(user);
    res.json({ token, user: { id: user.id, email: user.email } });
  });
});

app.post('/api/auth/login', (req, res) => {
  const { email, password } = req.body;
  db.get('SELECT * FROM users WHERE email = ?', [email], async (err, row) => {
    if (err) return res.status(500).json({ error: err.message });
    if (!row) return res.status(400).json({ error: 'Invalid credentials' });
    const ok = await bcrypt.compare(password, row.password_hash);
    if (!ok) return res.status(400).json({ error: 'Invalid credentials' });
    const token = signToken(row);
    res.json({ token, user: { id: row.id, email: row.email, is_admin: row.is_admin } });
  });
});

/* --- Create QR --- */
app.post('/api/qr/create', authMiddleware, upload.single('logo'), (req, res) => {
  const { originalUrl, currentUrl, meta } = req.body;
  const owner = req.user.id;
  const shortId = shortid.generate();
  const logoPath = req.file ? `/uploads/${req.file.filename}` : null;
  const curUrl = currentUrl || originalUrl;
  const metaJson = meta ? JSON.stringify(meta) : null;
  db.run(
    `INSERT INTO qrcodes (shortId, owner, originalUrl, currentUrl, logoPath, meta) VALUES (?,?,?,?,?,?)`,
    [shortId, owner, originalUrl, curUrl, logoPath, metaJson],
    function(err) {
      if (err) return res.status(500).json({ error: err.message });
      db.get('SELECT * FROM qrcodes WHERE id = ?', [this.lastID], (err2, row) => {
        if (err2) return res.status(500).json({ error: err2.message });
        // Return the short link to be encoded into a QR
        const shortLink = `${APP_HOST}/r/${row.shortId}`;
        res.json({ qr: row, shortLink });
      });
    }
  );
});

/* --- Edit QR (update destination) --- */
app.put('/api/qr/:id', authMiddleware, (req, res) => {
  const id = req.params.id;
  const { currentUrl } = req.body;
  db.get('SELECT * FROM qrcodes WHERE id = ?', [id], (err, row) => {
    if (err || !row) return res.status(404).json({ error: 'Not found' });
    if (row.owner !== req.user.id && !req.user.is_admin) return res.status(403).json({ error: 'Forbidden' });
    db.run('UPDATE qrcodes SET currentUrl = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?', [currentUrl, id], function(err2) {
      if (err2) return res.status(500).json({ error: err2.message });
      db.get('SELECT * FROM qrcodes WHERE id = ?', [id], (err3, updated) => {
        res.json({ qr: updated });
      });
    });
  });
});

/* --- Delete QR --- */
app.delete('/api/qr/:id', authMiddleware, (req, res) => {
  const id = req.params.id;
  db.get('SELECT * FROM qrcodes WHERE id = ?', [id], (err, row) => {
    if (err || !row) return res.status(404).json({ error: 'Not found' });
    if (row.owner !== req.user.id && !req.user.is_admin) return res.status(403).json({ error: 'Forbidden' });
    db.run('DELETE FROM qrcodes WHERE id = ?', [id], function(err2) {
      if (err2) return res.status(500).json({ error: err2.message });
      res.json({ ok: true });
    });
  });
});

/* --- History --- */
app.get('/api/qr/history', authMiddleware, (req, res) => {
  db.all('SELECT * FROM qrcodes WHERE owner = ? ORDER BY created_at DESC', [req.user.id], (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ qrs: rows });
  });
});

/* --- Admin: list totals --- */
app.get('/api/admin/stats', authMiddleware, (req, res) => {
  if (!req.user.is_admin) return res.status(403).json({ error: 'Forbidden' });
  db.get('SELECT COUNT(*) as total FROM qrcodes', [], (err, r1) => {
    db.get('SELECT COUNT(*) as users FROM users', [], (err2, r2) => {
      res.json({ totalQrs: r1.total, totalUsers: r2.users });
    });
  });
});

/* --- Redirect route: the dynamic magic --- */
app.get('/r/:shortId', (req, res) => {
  const shortId = req.params.shortId;
  db.get('SELECT * FROM qrcodes WHERE shortId = ?', [shortId], (err, row) => {
    if (err || !row) return res.status(404).send('Not found');
    // increment scans (non-blocking)
    db.run('UPDATE qrcodes SET scans = scans + 1 WHERE id = ?', [row.id]);
    // perform redirect to currentUrl
    let dest = row.currentUrl || row.originalUrl;
    // very small safety: ensure protocol
    if (!dest.startsWith('http://') && !dest.startsWith('https://')) dest = 'https://' + dest;
    res.redirect(dest);
  });
});

/* --- Simple search/validate for abusive URLs (basic) --- */
app.post('/api/admin/disable', authMiddleware, (req, res) => {
  if (!req.user.is_admin) return res.status(403).json({ error: 'Forbidden' });
  const { shortId } = req.body;
  // simple example: set currentUrl to about:blank or delete
  db.run('UPDATE qrcodes SET currentUrl = ? WHERE shortId = ?', ['about:blank', shortId], function(err) {
    if(err) return res.status(500).json({ error: err.message });
    res.json({ ok: true });
  });
});

/* --- Public: get QR info (for preview) --- */
app.get('/api/qr/:shortId', (req, res) => {
  const shortId = req.params.shortId;
  db.get('SELECT * FROM qrcodes WHERE shortId = ?', [shortId], (err, row) => {
    if (err || !row) return res.status(404).json({ error: 'Not found' });
    res.json({ qr: row, shortLink: `${APP_HOST}/r/${row.shortId}` });
  });
});

app.listen(PORT, () => {
  console.log(`Server running on ${PORT}`);
});
